/*
 * Assinatura do metodo: nome do recurso, metodo que o recurso manipula e URI.
 */
RESOURCE(helloworld, METHOD_GET, "hello", "title=\"Hello world ?len=0..\";rt=\"Text\"");

/*
 * Handleer function [nome do recurso]_handle (Deve ser implementado para cada recurso)
 * Um ponteiro para buffer, no qual a conteudo (payload) da resposta sera anexado.
 * Recursos simples podem ignorar os parametros preferred_size e offset, mas devem 
 * respeitar REST_MAX_CHUNK_SIZE (limite do buffer).
 */
void helloworld_handler(void* request, void* response, uint8_t *buffer, uint16_t preferred_size, int32_t *offset) {
  const char *len = NULL;
  char const * const message = "Hello World!"; 
  int length = 12; /*           |<-------->| */

  /* A URI solicitada pode ser recuperada usando rest_get_query() ou usando um parser que retorna chave-valor. */
  if (REST.get_query_variable(request, "len", &len)) {
    length = atoi(len);
    if (length<0) length = 0;
	if (length>REST_MAX_CHUNK_SIZE) length = REST_MAX_CHUNK_SIZE;
    memcpy(buffer, message, length);
  } else {
    memcpy(buffer, message, length);
  }

  REST.set_header_content_type(response, REST.type.TEXT_PLAIN);
  REST.set_header_etag(response, (uint8_t *) &length, 1);
  REST.set_response_payload(response, buffer, length);
}

/* Inicializa a REST engine. */
rest_init_engine();

/* Habilita o recurso. */
rest_activate_resource(&helloworld);


