#define PARENT_RESOURCE(name, attributes, get_handler, post_handler, put_handler, delete_handler)

