#ifndef _BLIP_TINYOS_INCLUDES_H
#define _BLIP_TINYOS_INCLUDES_H

#include <stddef.h>
#include <stdint.h>

#include "nwbyte.h"

#endif
