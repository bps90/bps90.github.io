#ifndef TEST_CONFIG_H_
#define TEST_CONFIG_H_

#ifndef ACCOMP
#define ACCOMP 1
#endif

#ifndef FRAME_SIZE
#define FRAME_SIZE 32
#endif /* FRAME_SIZE */

#ifndef REPETITIONS
#define REPETITIONS 1
#endif /* REPETITIONS */

#ifndef FULL_DUPLEX
#define FULL_DUPLEX 0
#endif

#endif /* TEST_CONFIG_H_ */
