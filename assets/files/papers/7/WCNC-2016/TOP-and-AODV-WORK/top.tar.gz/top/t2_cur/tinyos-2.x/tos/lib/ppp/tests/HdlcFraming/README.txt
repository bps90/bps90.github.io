A unit test for the HdlcFramingC component.
