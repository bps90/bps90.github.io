Sht11 Test Sensor

A simple application to demonstrate/test the SHT11 on the Intel Mote 2 sensorboard.

NOTE: If using the debug/programming board you must set SW5 to either the 
SPI or I2C settings for the SHT11 to work correctly.

