# Matrix: Multihop Address allocation and dynamic any-To-any Routing for 6LoWPAN

## [Log de mudanças]
  - Correção dos 143 erros de compilação
  - Fig 1 - layout (ainda precisa de mudanças)
  - Tikz
    -  Fig 2, 3 e 4.
  - Tabela 2
    - Nova nomenclatura para os cenários
  - Graficos no ggplot2
    - Fig 6,7,8,9,10,11
  - Apliquei o corretor grammaly (somente erros básicos)
    - Ainda estão presentes sentenças na voz passiva
  - Outros
    - Ajustes de sentenças na introdução e visão geral